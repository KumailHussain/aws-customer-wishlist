'use strict';

const databaseManager = require('../customer-db-handler/customer-db-params');

module.exports.handleResponse = res => {

        return res;

}

module.exports.createItem = async data => {
    const res = await saveWishList(data);

    return this.handleResponse(res);
}

module.exports.deleteDuplicateItem = async event => {
    const res = await databaseManager.getAllItems();

    return this.handleResponse(res);
}

async function saveWishList(data) {
    const post  = {
     "id": data.id,
     "pid": data.pid,
     "uid": data.uid,
     "productDetails": data.productDetails
  }
    return await databaseManager.saveItem(post);
}

module.exports.wasGreeted = async name => {
    const item = await databaseManager.getItem(name);
    return (item !== undefined) ? true : false
}