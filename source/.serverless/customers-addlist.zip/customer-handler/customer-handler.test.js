'use strict';

const customer = require('./customer');
const databaseManagerMock = require('../customer-db-handler/customer-db-params');


describe('saveItem', () => {
    test('test o save the item in db', () => {
        var params =  {
            "pid": "p2",
            "id": "918342s121212",
            "uid": "5d0c80a4562f6b5a105eedf4",
            "productDetails": {
                 "name": "White Cotton Winter Musical T-Shirt For Men",
        "image": "https://d30fs77zq6vq2v.cloudfront.net/images/product/large/22022019/1_tk5u-b9-457159977494.jpg"
      }
    }
        var res = { statusCode: '201', message: 'Item Added Succesfully'}
        databaseManagerMock.saveItem = jest.fn().mockReturnValue(res);

        return customer.createItem(params).then(greet => {
            console.log(greet)
            expect(databaseManagerMock.saveItem).toBeCalledTimes(1);
            expect(greet.statusCode).toBe("201");
        });
    });
});
describe('saveFaik', () => {
    test('test o save the item in db', () => {
        var params =  {

      }

    var res = { statusCode: '401', message: 'Item Added Succesfully'}
        databaseManagerMock.saveItem = jest.fn().mockReturnValue(res);

        return customer.createItem(params).then(greet => {
            console.log(greet)
            expect(databaseManagerMock.saveItem).toBeCalledTimes(1);
            expect(greet.statusCode).toBe("401");
        });
    });
});