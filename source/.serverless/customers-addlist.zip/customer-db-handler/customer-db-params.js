'use strict';

var databaseManager = require('./customer-db-connector');

module.exports.saveItem = async item => {
    const params = {
        TableName: process.env.TABLE_NAME,
        Item: item
    };

    return await databaseManager.saveItem(params);
}

module.exports.getAllItems = async data => {
    const params = {
        TableName: process.env.TABLE_NAME
    };

    return await databaseManager.getAllItems(params);
}

module.exports.deleteDuplicateItems = async data => {
    const params = data

    return await databaseManager.deleteDuplicateItems(params);
}