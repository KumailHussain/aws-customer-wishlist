'use strict';
const  responseHandler = require('./response-handler');
var testData  = require('../../dummy-test-input/customer-list.json')
const databaseManagerMock = require('../customer-db-handler/customer-db-params');


describe('itemAddSuccess', () => {
    test('response for Item added success', () => {

        const res = responseHandler.itemAddSuccess();
        expect(res.statusCode).toBe('201');

    });
});

describe('getItemAndDelete', () => {
    test('delete the items when Duplicate data is available', () => {

        const res = responseHandler.getItemAndDelete(testData);
        const dbResponse = { statusCode: '201', message: 'Item Deleted Succesfully'}
        databaseManagerMock.deleteDuplicateItems = jest.fn().mockReturnValue(dbResponse);
        expect(res.statusCode).toBe('201');

    });
});